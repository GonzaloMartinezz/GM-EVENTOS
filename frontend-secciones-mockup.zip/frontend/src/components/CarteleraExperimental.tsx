import { Link } from 'react-router-dom';
import { EventItem } from '../types/event';

/**
 * Cartelera experimental — la "cola larga" de la agenda: shows más chicos,
 * bares, under y circuitos independientes que no entran en el line-up
 * principal. Estética densa y cruda a propósito (texto, sin cards).
 */
export default function CarteleraExperimental({ events }: { events: EventItem[] }) {
  if (events.length === 0) return null;

  const total = events.length;

  return (
    <div className="experimental">
      <div className="experimental-count" aria-hidden="true">
        {String(total).padStart(3, '0')}
      </div>

      <ul className="experimental-list">
        {events.map((event, idx) => (
          <li key={event._id} className="experimental-row">
            <span className="experimental-idx">{String(idx + 1).padStart(2, '0')}</span>
            <Link to={`/eventos/${event.slug}`} className="experimental-name">
              {event.artistName}
            </Link>
            <span className="experimental-venue">{event.venueName} — {event.city}</span>
            <span className="experimental-date">
              {new Date(event.startDate).toLocaleDateString('es-AR', { day: '2-digit', month: 'short' })}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
