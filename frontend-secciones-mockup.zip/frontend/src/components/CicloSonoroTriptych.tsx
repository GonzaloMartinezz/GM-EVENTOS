import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { EventItem } from '../types/event';

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('es-AR', { day: '2-digit', month: 'short' }).toUpperCase();
}

/**
 * Tríptico / retícula suiza — tres paneles de igual ancho, separados por
 * líneas finas (hairlines), con numeración tipográfica grande en la
 * esquina de cada panel. Estética "Swiss grid": mucho aire, tipografía
 * como protagonista, sin decoración de más.
 */
export default function CicloSonoroTriptych({ events }: { events: EventItem[] }) {
  const panels = events.slice(0, 3);
  if (panels.length === 0) return null;

  return (
    <div className="triptych-grid">
      {panels.map((event, idx) => (
        <motion.div
          key={event._id}
          className="triptych-col"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.5, delay: idx * 0.1 }}
        >
          <span className="triptych-index">{String(idx + 1).padStart(2, '0')}</span>

          <div className="triptych-body">
            <span className="mkt-eyebrow">{event.category}</span>
            <h3 className="triptych-artist">{event.artistName}</h3>

            <div className="triptych-rule" />

            <div className="triptych-meta">
              <span>{formatDate(event.startDate)}</span>
              <span>{event.venueName}</span>
              <span>{event.city}</span>
            </div>

            <Link to={`/eventos/${event.slug}`} className="triptych-link">
              Ver evento <span className="headliner-arrow">↗</span>
            </Link>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
