import { Link } from 'react-router-dom';
import { EventItem } from '../types/event';

/**
 * Circuito & ruteo regional — "dates archive": los próximos eventos
 * organizados por día, mostrando en qué ciudad/provincia toca cada uno,
 * como un mapa de ruta regional (Tucumán, Buenos Aires, Córdoba...).
 */
export default function CircuitoRegional({ events }: { events: EventItem[] }) {
  const upcoming = events.slice(0, 8);
  if (upcoming.length === 0) return null;

  return (
    <div className="circuito">
      {upcoming.map((event) => {
        const date = new Date(event.startDate);
        return (
          <Link key={event._id} to={`/eventos/${event.slug}`} className="circuito-item">
            <div className="circuito-day">
              <span className="circuito-weekday">
                {date.toLocaleDateString('es-AR', { weekday: 'short' }).replace('.', '').toUpperCase()}
              </span>
              <span className="circuito-num">{date.toLocaleDateString('es-AR', { day: '2-digit' })}</span>
            </div>
            <div className="circuito-info">
              <span className="circuito-artist">{event.artistName}</span>
              <span className="circuito-region">{event.city} · {event.province}</span>
            </div>
          </Link>
        );
      })}
    </div>
  );
}
