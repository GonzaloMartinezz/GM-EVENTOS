import { Link } from 'react-router-dom';
import { EventItem } from '../types/event';

type Banda = { label: string; range: string; events: EventItem[] };

/**
 * Cronograma semanal en franjas modulares: agrupa los eventos de los
 * próximos días por momento del día (mañana / tarde / noche), como una
 * grilla horaria de festival.
 */
export default function CronogramaSemanal({ events }: { events: EventItem[] }) {
  const bandas: Banda[] = [
    { label: 'Mañana', range: '09 – 13 HS', events: [] },
    { label: 'Tarde', range: '14 – 18 HS', events: [] },
    { label: 'Noche', range: '19 – 00 HS', events: [] },
  ];

  events.forEach((event) => {
    const hour = new Date(event.startDate).getHours();
    if (hour < 14) bandas[0].events.push(event);
    else if (hour < 19) bandas[1].events.push(event);
    else bandas[2].events.push(event);
  });

  return (
    <div className="franjas">
      {bandas.map((banda) => (
        <div key={banda.label} className="franja-col">
          <div className="franja-head">
            <span className="franja-label">{banda.label}</span>
            <span className="franja-range">{banda.range}</span>
          </div>

          {banda.events.length === 0 && <p className="franja-empty">Sin shows en esta franja.</p>}

          <ul className="franja-list">
            {banda.events.slice(0, 5).map((event) => (
              <li key={event._id}>
                <Link to={`/eventos/${event.slug}`}>
                  <span className="franja-time">
                    {new Date(event.startDate).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  <span className="franja-artist">{event.artistName}</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
