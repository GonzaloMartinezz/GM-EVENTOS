import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { EventItem } from '../types/event';

function formatDay(iso: string) {
  return new Date(iso).toLocaleDateString('es-AR', { day: '2-digit' });
}
function formatMonth(iso: string) {
  return new Date(iso).toLocaleDateString('es-AR', { month: 'short' }).replace('.', '').toUpperCase();
}

/**
 * "FUJI" — poster monumental contextual.
 * Inspirado en el afiche minimalista japonés (círculo + tipografía enorme
 * + mucho aire). "Contextual": siempre muestra el próximo evento que
 * viene en la agenda, así el poster cambia solo a medida que pasan los
 * shows — no hay que editarlo a mano.
 */
export default function FujiPoster({ event }: { event?: EventItem }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const sunY = useTransform(scrollYProgress, [0, 1], [-40, 40]);
  const textY = useTransform(scrollYProgress, [0, 1], [30, -30]);

  if (!event) return null;

  return (
    <section ref={ref} className="fuji">
      <motion.div className="fuji-sun" style={{ y: sunY }} aria-hidden="true" />

      <div className="container fuji-inner">
        <motion.div className="fuji-eyebrow" style={{ y: textY }}>
          <span className="mkt-eyebrow">Lo próximo en la agenda</span>
        </motion.div>

        <motion.div className="fuji-date" style={{ y: textY }}>
          <span className="fuji-day">{formatDay(event.startDate)}</span>
          <span className="fuji-month">{formatMonth(event.startDate)}</span>
        </motion.div>

        <motion.h2 className="fuji-artist mkt-display">{event.artistName}</motion.h2>

        <div className="fuji-meta">
          <span>{event.venueName}</span>
          <span>{event.city}</span>
          {!event.isFree && event.tickets?.[0] && (
            <span>Desde ${event.tickets[0].price.toLocaleString('es-AR')}</span>
          )}
          {event.isFree && <span>Entrada libre y gratuita</span>}
        </div>

        <Link to={`/eventos/${event.slug}`} className="btn btn-primary fuji-cta">
          Ver este evento
        </Link>
      </div>
    </section>
  );
}
