import { Link } from 'react-router-dom';

export default function Header() {
  return (
    <header className="site-header">
      <div className="container">
        <Link to="/" className="brand">
          Agenda<span>Cultural</span>
        </Link>
        <nav className="header-nav">
          <Link to="/agenda">Agenda</Link>
          <a href="/#lineup">Line-up</a>
          <a href="/#calendario">Calendario</a>
          <Link to="/como-funciona">Cómo funciona</Link>
          <Link to="/admin/login">Panel admin</Link>
        </nav>
      </div>
    </header>
  );
}
