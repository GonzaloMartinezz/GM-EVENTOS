/**
 * "¿Producís o tocás en Tucumán?" — CTA para artistas/productores que
 * quieren sumar su propio evento a la agenda. Por ahora deriva a mail;
 * el día de mañana puede apuntar a un formulario propio.
 */
export default function ProducerCta() {
  return (
    <div className="producer-cta">
      <div>
        <h3 className="mkt-display producer-cta-title">¿Producís o tocás en Tucumán?</h3>
        <p className="producer-cta-sub">
          Contanos de tu show y lo sumamos a la agenda: fecha, lugar, banda y dónde comprar la entrada.
        </p>
      </div>
      <a href="mailto:agenda@agendacultural.com.ar?subject=Quiero%20sumar%20mi%20evento" className="btn btn-outline">
        Sumar mi evento
      </a>
    </div>
  );
}
