import { EventItem } from '../types/event';

/**
 * Salas & espacios activos — directorio de venues que salen en la
 * agenda actual, con la cantidad de eventos cargados en cada uno.
 * Pensado para la sección del footer, como en el mockup.
 */
export default function VenuesDirectory({ events }: { events: EventItem[] }) {
  const map = new Map<string, { city: string; count: number }>();
  events.forEach((e) => {
    const entry = map.get(e.venueName);
    if (entry) entry.count += 1;
    else map.set(e.venueName, { city: e.city, count: 1 });
  });

  const venues = Array.from(map.entries())
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 8);

  if (venues.length === 0) return null;

  return (
    <div className="venues-directory">
      {venues.map(([name, info]) => (
        <div key={name} className="venues-row">
          <span className="venues-name">{name}</span>
          <span className="venues-city">{info.city}</span>
          <span className="venues-count">{String(info.count).padStart(2, '0')}</span>
        </div>
      ))}
    </div>
  );
}
