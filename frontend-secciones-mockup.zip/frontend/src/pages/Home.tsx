import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import HeroMkt from '../components/HeroMkt';
import Marquee from '../components/Marquee';
import Reveal from '../components/Reveal';
import SectionLabel from '../components/SectionLabel';
import ParallaxCity from '../components/ParallaxCity';
import HeadlinerList from '../components/HeadlinerList';
import StatsStrip from '../components/StatsStrip';
import CalendarStrip from '../components/CalendarStrip';
import NumberedGrid from '../components/NumberedGrid';
import ListingRow from '../components/ListingRow';
import SearchBar from '../components/SearchBar';
import EventCard from '../components/EventCard';
import FujiPoster from '../components/FujiPoster';
import CronogramaSemanal from '../components/CronogramaSemanal';
import CicloSonoroTriptych from '../components/CicloSonoroTriptych';
import CircuitoRegional from '../components/CircuitoRegional';
import CarteleraExperimental from '../components/CarteleraExperimental';
import ProducerCta from '../components/ProducerCta';
import { fetchEvents } from '../services/eventService';
import { fetchSettings } from '../services/settingsService';
import { EventItem, EventCategory, CATEGORY_LABELS } from '../types/event';
import { SiteSettings } from '../types/settings';

const DEFAULT_SETTINGS: SiteSettings = {
  heroEyebrow: 'Tucumán · Buenos Aires · 2026',
  heroTitleLine1: 'Todo lo que pasa',
  heroTitleAccent: 'acá.',
  heroSubtitle:
    'Conciertos, teatro, stand up y festivales. Enterate, buscá tu banda favorita y comprá la entrada sin perderte nada.',
  heroPrimaryCta: 'Ver line-up',
  heroSecondaryCta: 'Ver calendario',
  sectionCategoriesEyebrow: 'Explorá por tipo',
  sectionCategoriesTitle: 'Categorías de eventos',
  categoryDescriptions: {
    concierto: 'Bandas locales y nacionales, en vivo.',
    teatro: 'Elencos y obras clásicas o contemporáneas.',
    standup: 'Humoristas tucumanos arriba del escenario.',
    festival: 'Varias bandas, un solo line-up.',
    exposicion: 'Arte, fotografía y muestras abiertas al público.',
    deportivo: 'Torneos y eventos deportivos con público.',
    otro: 'Ferias, actividades y propuestas culturales libres.',
  },
  sectionLineupEyebrow: 'Lo más destacado',
  sectionLineupTitle: 'Próximos headliners',
  sectionCalendarEyebrow: 'Próximos 14 días',
  sectionCalendarTitle: 'Calendario',
  ctaEyebrow: 'No te pierdas nada',
  ctaTitle: 'Aprovechá todo lo que pasa en Tucumán',
  ctaButtonLabel: 'Quiero enterarme',
  footerText: 'Agenda Cultural · Conciertos, teatro, stand up y más — en Tucumán y Buenos Aires',
};

/**
 * ORDEN DE LA HOME (pensado para alguien que llega buscando "qué hay para hacer"):
 * 01 Hero                  → dice de qué va el sitio
 * 02 Buscador               → lo primero que alguien quiere hacer: buscar/filtrar
 * 03 Lo próximo (Fuji)      → poster monumental contextual del evento más cercano
 * 04 Categorías             → para quien no busca algo puntual, navega por tipo
 * 05 Calendario             → para quien piensa en fechas ("¿qué hay este finde?")
 * 06 Cronograma semanal     → franjas horarias (mañana/tarde/noche)
 * 07 Headliners             → lo más destacado, para inspirar
 * 08 Ciclo Sonoro           → tríptico retícula suiza, 3 shows en foco
 * —  Ciudad                 → refuerzo de marca / pausa visual
 * 09 Circuito regional      → próximas fechas por ciudad/provincia
 * 10 Cartelera experimental → shows chicos, under, circuito independiente
 * 11 En números             → contexto/confianza (cuánto hay cargado)
 * 12 Próximos eventos       → lista concreta + link a la agenda completa
 * —  ¿Producís o tocás?     → CTA para sumar tu propio evento
 * 13 Salas & espacios       → directorio de venues (vive en el Footer)
 * Newsletter/Footer         → chrome global, sin numerar
 */
export default function Home() {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);

  const [q, setQ] = useState('');
  const [category, setCategory] = useState<EventCategory | ''>('');
  const [city, setCity] = useState('');
  const [searchResults, setSearchResults] = useState<EventItem[] | null>(null);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    setLoading(true);
    Promise.all([fetchEvents({ limit: 50 }), fetchSettings().catch(() => null)])
      .then(([eventsRes, settingsRes]) => {
        setEvents(eventsRes.data);
        if (settingsRes) setSettings(settingsRes);
      })
      .catch(() => setError('No pudimos cargar la agenda. Probá de nuevo en unos minutos.'))
      .finally(() => setLoading(false));
  }, []);

  async function handleSearch() {
    if (!q && !category && !city) {
      setSearchResults(null);
      return;
    }
    setSearching(true);
    try {
      const res = await fetchEvents({ q, category, city, limit: 12 });
      setSearchResults(res.data);
    } finally {
      setSearching(false);
    }
  }

  const headliners = useMemo(() => {
    const featured = events.filter((e) => e.featured);
    const rest = events.filter((e) => !e.featured);
    return [...featured, ...rest].slice(0, 5);
  }, [events]);

  const nextEvent = events[0];

  const experimentalEvents = useMemo(
    () => events.filter((e) => !headliners.some((h) => h._id === e._id)).slice(0, 10),
    [events, headliners]
  );

  const stats = useMemo(() => {
    const cities = new Set(events.map((e) => e.city)).size;
    const freeCount = events.filter((e) => e.isFree).length;
    const categoriesCount = new Set(events.map((e) => e.category)).size;
    return [
      { value: String(events.length).padStart(2, '0'), label: 'Eventos en agenda' },
      { value: String(cities).padStart(2, '0'), label: 'Ciudades' },
      { value: String(categoriesCount).padStart(2, '0'), label: 'Categorías activas' },
      { value: String(freeCount).padStart(2, '0'), label: 'Eventos gratuitos' },
    ];
  }, [events]);

  const categoryItems = (Object.entries(CATEGORY_LABELS) as [EventCategory, string][]).map(
    ([value, label]) => ({
      title: label,
      description: settings.categoryDescriptions?.[value] || DEFAULT_SETTINGS.categoryDescriptions[value],
    })
  );

  const preview = events.slice(0, 4);

  return (
    <div>
      <Header />

      {/* 01 — Hero */}
      <HeroMkt
        eyebrow={settings.heroEyebrow}
        titleLine1={settings.heroTitleLine1}
        titleAccent={settings.heroTitleAccent}
        sub={settings.heroSubtitle}
        primaryCta={settings.heroPrimaryCta}
        secondaryCta={settings.heroSecondaryCta}
        bgWord="Agenda"
      />

      <Marquee
        items={
          headliners.length
            ? headliners.map((e) => e.artistName)
            : ['Concierto', 'Teatro', 'Stand up', 'Festival']
        }
      />

      {/* 02 — Buscador */}
      <section className="mkt-section mkt-section--dark">
        <div className="container" style={{ padding: '70px 20px 20px' }}>
          <Reveal>
            <SectionLabel number="02" eyebrow="Buscá el tuyo" title="Encontrá tu evento" />
          </Reveal>
          <div style={{ marginTop: 30 }}>
            <SearchBar
              q={q}
              category={category}
              city={city}
              onChangeQ={setQ}
              onChangeCategory={setCategory}
              onChangeCity={setCity}
              onSubmit={handleSearch}
            />
          </div>
        </div>

        <div className="container">
          {searching && <p className="empty-state">Buscando...</p>}
          {!searching && searchResults && (
            <>
              {searchResults.length === 0 ? (
                <p className="empty-state">No encontramos eventos con esos filtros.</p>
              ) : (
                <div className="events-grid">
                  {searchResults.map((event) => (
                    <EventCard key={event._id} event={event} />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {!searchResults && (
        <>
          {/* 03 — Lo próximo (FUJI: poster monumental contextual) */}
          <section className="mkt-section">
            <div className="container" style={{ padding: '50px 20px 0' }}>
              <Reveal>
                <SectionLabel number="03" eyebrow="El próximo en subir al escenario" title="Lo próximo" />
              </Reveal>
            </div>
            <FujiPoster event={nextEvent} />
          </section>

          {/* 04 — Categorías */}
          <section className="mkt-section mkt-section--dark">
            <div className="container" style={{ padding: '70px 20px 70px' }}>
              <Reveal>
                <SectionLabel
                  number="04"
                  eyebrow={settings.sectionCategoriesEyebrow}
                  title={settings.sectionCategoriesTitle}
                />
              </Reveal>
              <NumberedGrid items={categoryItems} />
            </div>
          </section>

          {/* 05 — Calendario */}
          <section id="calendario" className="mkt-section mkt-section--dark">
            <div className="container" style={{ padding: '0 20px 70px' }}>
              <Reveal>
                <SectionLabel
                  number="05"
                  eyebrow={settings.sectionCalendarEyebrow}
                  title={settings.sectionCalendarTitle}
                />
              </Reveal>
              <CalendarStrip events={events} />
            </div>
          </section>

          {/* 06 — Cronograma semanal (franjas modulares) */}
          <section className="mkt-section mkt-section--dark">
            <div className="container" style={{ padding: '0 20px 70px' }}>
              <Reveal>
                <SectionLabel
                  number="06"
                  eyebrow="Mañana, tarde o noche"
                  title="Cronograma semanal"
                />
              </Reveal>
              <CronogramaSemanal events={events} />
            </div>
          </section>

          {/* 07 — Headliners */}
          <section id="lineup" className="mkt-section mkt-section--orange">
            <div className="container" style={{ padding: '70px 20px' }}>
              <Reveal>
                <SectionLabel
                  number="07"
                  eyebrow={settings.sectionLineupEyebrow}
                  title={settings.sectionLineupTitle}
                />
              </Reveal>

              {loading && <p style={{ marginTop: 30 }}>Cargando line-up...</p>}
              {!loading && headliners.length === 0 && (
                <p style={{ marginTop: 30 }}>Todavía no hay eventos cargados.</p>
              )}
              {!loading && headliners.length > 0 && <HeadlinerList events={headliners} />}
            </div>
          </section>

          {/* 08 — Ciclo Sonoro (tríptico, retícula suiza) */}
          <section className="mkt-section mkt-section--dark">
            <div className="container" style={{ padding: '70px 20px' }}>
              <Reveal>
                <SectionLabel number="08" eyebrow="Tríptico · retícula suiza" title="Ciclo Sonoro" />
              </Reveal>
              <CicloSonoroTriptych events={headliners} />
            </div>
          </section>

          {/* — Ciudad (parallax) */}
          <ParallaxCity
            city={nextEvent ? nextEvent.city.split(',')[0] : 'Tucumán'}
            caption={
              nextEvent
                ? `${nextEvent.artistName} // ${nextEvent.venueName}`
                : 'Tu próxima salida está por acá'
            }
          />

          {/* 09 — Circuito & ruteo regional (dates archive) */}
          <section className="mkt-section mkt-section--dark">
            <div className="container" style={{ padding: '70px 20px' }}>
              <Reveal>
                <SectionLabel
                  number="09"
                  eyebrow="Dates archive"
                  title="Circuito & ruteo regional"
                />
              </Reveal>
              <CircuitoRegional events={events} />
            </div>
          </section>

          {/* 10 — Cartelera experimental */}
          <section className="mkt-section mkt-section--dark">
            <div className="container" style={{ padding: '0 20px 70px' }}>
              <Reveal>
                <SectionLabel
                  number="10"
                  eyebrow="Under, bares y circuito indie"
                  title="Cartelera experimental"
                />
              </Reveal>
              <CarteleraExperimental events={experimentalEvents} />
            </div>
          </section>

          {/* 11 — En números */}
          <section className="mkt-section mkt-section--dark">
            <div className="container" style={{ padding: '60px 20px 10px' }}>
              <Reveal>
                <SectionLabel number="11" eyebrow="En números" title="La agenda, en números" align="center" />
              </Reveal>
            </div>
            <div className="container">
              <StatsStrip stats={stats} />
            </div>
          </section>

          {/* 12 — Próximos eventos (preview + link a la agenda completa) */}
          <section className="mkt-section mkt-section--dark">
            <div className="container" style={{ padding: '20px 20px 30px' }}>
              <Reveal>
                <SectionLabel number="12" eyebrow="Lo que se viene" title="Próximos eventos" />
              </Reveal>

              {loading && <p className="empty-state">Cargando...</p>}
              {!loading && error && <p className="empty-state">{error}</p>}
              {!loading && !error && preview.length === 0 && (
                <p className="empty-state">No hay eventos cargados todavía.</p>
              )}

              <div style={{ marginTop: 20 }}>
                {!loading &&
                  preview.map((event, idx) => (
                    <Reveal key={event._id} delay={idx * 0.04} y={12}>
                      <ListingRow event={event} />
                    </Reveal>
                  ))}
              </div>

              {!loading && events.length > 0 && (
                <div className="section-cta">
                  <Link to="/agenda" className="btn btn-primary">
                    Ver agenda completa
                  </Link>
                </div>
              )}

              <ProducerCta />
            </div>
          </section>
        </>
      )}

      <Footer settings={settings} events={events} />
    </div>
  );
}
